#!/bin/bash
# Checking the Service Status
service=$1
NOW=$(date +"%Y-%m-%d %H:%M.%S")
if [ -z "$service" ]; then
    echo "[${NOW}] usage: $0 <service-name>"
exit 1
fi

echo "[${NOW}] Checking $service status"
STATUS="$(systemctl --user is-active $service)"
RUNNING="$(systemctl --user show -p SubState $service | cut -d'=' -f2)"

if [ "${STATUS}" != "active" ] || [ "${RUNNING}" != "running" ];
then
    echo "[${NOW}] Starting $service"
    systemctl --user start $1
fi
